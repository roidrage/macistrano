# Copyright (c) 2006-2007, The RubyCocoa Project.
# Copyright (c) 2001-2006, FUJIMOTO Hisakuni.
# All Rights Reserved.
#
# RubyCocoa is free software, covered under either the Ruby's license or the 
# LGPL. See the COPYRIGHT file for more information.

require 'osx/objc/oc_all.rb'
require 'osx/objc/cocoa_macros'

p = '/System/Library/BridgeSupport/libSystem.bridgesupport'
OSX.load_bridge_support_file(p) if File.exist?(p)
